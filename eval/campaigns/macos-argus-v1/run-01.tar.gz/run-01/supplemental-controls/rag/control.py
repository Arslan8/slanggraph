"""Supplemental deterministic retrieval control; excluded from frozen cohort."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

parser = argparse.ArgumentParser()
parser.add_argument('run', type=Path)
args = parser.parse_args()
run = args.run.resolve()
sys.path.insert(0, str(run / 'harness/demos'))
import agentic_rag as rag
from langchain_core.messages import AIMessage, ToolMessage
from sklearn.feature_extraction.text import TfidfVectorizer

query = 'How do chain-of-thought and self-consistency prompting differ?'
fixture = Path('eval/campaigns/langgraph-demos-v1/fixtures/rag').resolve()
paths = [fixture / name for name in (
    '2023-06-23-agent.html',
    '2023-03-15-prompt-engineering.html',
    '2023-10-25-adv-attack-llm.html',
)]


class ControlledResponses:
    def __init__(self):
        self.calls = 0

    def invoke(self, runnable, messages):
        self.calls += 1
        if self.calls == 1:
            return AIMessage(content='', tool_calls=[dict(
                name='retrieve_blog_posts', args=dict(query=query), id='macos-retrieval-control'
            )])
        if self.calls == 2:
            return SimpleNamespace(binary_score='yes')
        if self.calls == 3:
            return AIMessage(content='Supplemental retrieval control finished.')
        raise AssertionError('unexpected model step')


rag.install_mac_policy('forbid(principal == slangGraph::User::"blocked", action, resource);')
controlled = ControlledResponses()
graph, security, dispatcher, audit = rag.build(paths, 'Argus', controlled)
config = rag.with_principal(
    {'recursion_limit': 50},
    rag.Principal('alice', frozenset(), frozenset(), 'D2-resource-monitor'),
    modules=security.modules,
)
result = graph.invoke({'messages': [('user', query)]}, config)
responses = [m.content for m in result['messages'] if isinstance(m, ToolMessage)]
assert len(responses) == 1
documents = rag.chunks(paths)
vectorizer = TfidfVectorizer(stop_words='english').fit(documents)
scores = (vectorizer.transform(documents) @ vectorizer.transform([query]).T).toarray().ravel()
expected = '\n\n'.join(documents[index] for index in scores.argsort()[-5:][::-1])
assert responses[0] == expected
assert len(dispatcher.activation_receipts()) == len(dispatcher.lifecycle_records()) == 1
assert dispatcher.audit_records()[0].allowed
value = dict(
    scope='Supplemental deterministic retrieval control; excluded from all 225 cohort attempts and utility rates.',
    model='No model request; controlled tool-selection, grading and generation responses.',
    controlled_steps=controlled.calls,
    retrieval_matches_original_baseline=True,
    retrieved_sha256=hashlib.sha256(expected.encode()).hexdigest(),
    messages=[m.model_dump() for m in result['messages']],
    authorization_decisions=[rag.serial(x) for x in audit.records()],
    authorization_grants=[rag.serial(x) for x in security.host_executor.authorization_grants()],
    activation_receipts=[dict(x.canonical()) for x in dispatcher.activation_receipts()],
    lowering_records=list(dispatcher.lowering_records()),
    lifecycle_records=list(dispatcher.lifecycle_records()),
    broker_audit=[rag.serial(x) for x in dispatcher.audit_records()],
)
destination = run / 'supplemental-controls/rag'
destination.mkdir(parents=True, exist_ok=False)
(destination / 'result.json').write_text(json.dumps(value, indent=2) + '\n')
(destination / 'control.py').write_text(Path(__file__).read_text())
print(json.dumps({key: value[key] for key in ('scope','controlled_steps','retrieval_matches_original_baseline')}))
