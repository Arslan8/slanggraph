import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
run = root / 'eval/campaigns/macos-argus-v1/run-01'
spec = importlib.util.spec_from_file_location('macos_archive_controls', root / 'eval/campaigns/macos-argus-v1/verify_evidence.py')
archive = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive)
spec = importlib.util.spec_from_file_location('macos_native_controls', root / 'eval/remaining/verify_macos_baseline.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
from langgraph.prebuilt.security.lean_lifecycle import LeanLifecycleChecker
from langgraph.prebuilt.security.macos import _boot_id, _process_identity

host = json.loads((run / 'macos-host-configuration.json').read_text())
lean = host['lean']
checker = LeanLifecycleChecker(str(run / 'libargus_worker_route.dylib'), lean['sha256'], str(run / 'libleanshared.dylib'), lean['native_runtime_sha256'])
rag_replays = native.native_journals(run / 'supplemental-controls/rag/native', checker, lean['sha256'])
assert rag_replays == 1
positive = run / 'native-evidence/pandas/rep-0/monthly_mean'
positive_replays = native.native_journals(positive, checker, lean['sha256'])
assert positive_replays >= 1
controls = []
for mutation in ('obligation', 'cleanup', 'receipt_context'):
    with tempfile.TemporaryDirectory() as name:
        folder = Path(name)
        for path in positive.glob('*.json'):
            shutil.copy2(path, folder / path.name)
        path = next(folder.glob('native-execution-*.json'))
        value = json.loads(path.read_text())
        if mutation == 'obligation':
            value['lifecycle_records'][0]['certificate']['obligations'][0]['selector'] = 'tampered'
        elif mutation == 'cleanup':
            value['lifecycle_records'][0]['cleanup_confirmed'] = False
        else:
            value['activation_receipts'][0]['context_digest'] = 'tampered'
        path.write_text(json.dumps(value))
        try:
            native.native_journals(folder, checker, lean['sha256'])
        except (ValueError, PermissionError) as error:
            controls.append(dict(mutation=mutation, rejected=True, reason=str(error)))
        else:
            raise AssertionError(f'accepted native mutation: {mutation}')

before = json.loads((run / 'source-before.json').read_text())
with tempfile.TemporaryDirectory() as name:
    folder = Path(name)
    for prefix in ('framework/libs', 'harness/demos', 'harness/pandas'):
        for path in (run / prefix).rglob('*.py'):
            destination = folder / path.relative_to(run)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
    assert archive.execution_copies(folder, before) == 333
    target = folder / 'framework/libs/prebuilt/langgraph/prebuilt/security/macos_object.py'
    original = target.read_bytes()
    for mutation in ('changed_execution_source', 'missing_execution_source', 'extra_execution_source'):
        target.write_bytes(original)
        extra = folder / 'harness/demos/unexpected.py'
        extra.unlink(missing_ok=True)
        if mutation == 'changed_execution_source':
            target.write_bytes(original + b'\n# changed\n')
        elif mutation == 'missing_execution_source':
            target.unlink()
        else:
            extra.write_text('pass\n')
        try:
            archive.execution_copies(folder, before)
        except ValueError as error:
            controls.append(dict(mutation=mutation, rejected=True, reason=str(error)))
        else:
            raise AssertionError(f'accepted snapshot mutation: {mutation}')

recovery = []
for path in Path(host['recovery_directory']).glob('*.json'):
    value = json.loads(path.read_text())
    value['record'] = path.name
    value['original_process_absent'] = value['boot_id'] != _boot_id() or _process_identity(value['pid']) != value['start_time']
    assert value['original_process_absent']
    recovery.append(value)

observations = []
events = json.loads((run / 'sleep-wake-events.json').read_text())['events']
timed = [(datetime.strptime(e['time'], '%Y-%m-%d %H:%M:%S %z').timestamp(), e) for e in events]
for line in (run / 'trials.jsonl').read_text().splitlines():
    row = json.loads(line)
    if row['status'] != 'compatibility_failed' or row['application'] == 'T10-time-travel':
        continue
    folder = run / 'demos' / f"rep-{row['repetition']}" / row['application'] / f"task-{row['task']}" / 'Argus'
    start, end = folder.stat().st_birthtime, (folder / 'trial.json').stat().st_mtime
    observations.append(dict(application=row['application'], repetition=row['repetition'], task=row['task'], directory_created_utc=datetime.fromtimestamp(start, timezone.utc).isoformat(), record_written_utc=datetime.fromtimestamp(end, timezone.utc).isoformat(), sleep_wake_events=[e for t,e in timed if start <= t <= end]))
assert len(observations) == 5 and all(x['sleep_wake_events'] for x in observations)
report = dict(supplemental_rag_replays=rag_replays, monthly_mean_native_replays=positive_replays, mutations=controls, retained_recovery_records=recovery, channel_failure_sleep_overlap=observations, timing_scope='Directory creation and trial record write delimit a diagnostic interval; these are not replacements for the original timing boundary.')
(run / 'validation/final-evidence-controls.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, run / 'validation/final-evidence-controls.py')
print(json.dumps(dict(rag_replays=rag_replays, mutations_rejected=len(controls), absent_original_processes=len(recovery), channel_failure_intervals_overlapping_sleep=len(observations))))
