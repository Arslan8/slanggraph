# Matched Pandas complete-system overhead

## Primary result

| Condition | Internal configuration | Attempts | Success | Timeouts | Mean complete-system wall time |
|---|---|---:|---:|---:|---:|
| Baseline | `Baseline` | 50 | 50/50 | 0/50 | 14373.0 ms |
| slangGraph | `C-full-lean` | 50 | 45/50 | 0/50 | 15235.6 ms |

Across the complete set of 100 attempted task trials, slangGraph is **1.060x** the Baseline runtime, or **6.0% overhead**. The paired-block 95% interval is **[1.042x, 1.088x]**, corresponding to **[4.2%, 8.8%]** overhead.

The interval is a percentile bootstrap of the ratio of means with 100,000 resamples and seed `20261030`. Each resampling unit is one paired repetition block containing all ten tasks in both conditions. With only five blocks, precision is limited; the 100 task trials are not treated as independent repetitions.

Timeouts use a 180,000 ms cap in the primary estimand. The table reports timeout counts explicitly; capped durations are retained rather than discarded.

## Correctness and matched-success sensitivity

Baseline succeeded on 50/50 attempts; Argus succeeded on 45/50. All protected attempts failed at host activation before computation because mandatory bubblewrap isolation was unavailable. The secondary matched-success analysis contains 45 task/repetition pairs, with means 14166.7 ms and 15035.8 ms and ratio 1.061x.

## Measurement boundary

Both conditions use the same subprocess wall-clock boundary: interpreter startup, application preparation, model callbacks, retries, computation, conversions, and output production. Common campaign preparation and shared model warmup are excluded symmetrically and recorded in `raw/setup.json`. Argus selects closed admission, principal and sealed operator policies, dataset/resource mediation, Linux isolation, security audit, output mediation, preflight-only integrity checking, and the pinned inline native lifecycle checker. Baseline uses direct dataset loading and the application's vendor sandbox subprocess with no Argus authorization, activation, broker, audit, or runtime validator.

![Matched Pandas overhead](application-overhead.svg)
